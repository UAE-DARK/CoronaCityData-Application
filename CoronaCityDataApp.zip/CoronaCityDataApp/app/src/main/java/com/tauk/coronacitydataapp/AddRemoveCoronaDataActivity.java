package com.tauk.coronacitydataapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AddRemoveCoronaDataActivity extends AppCompatActivity {

    //declare variables as needed for edit texts, tvStatus .....
    private EditText etCity;
    private EditText etCases;
    private EditText etRecoveries;

    private TextView tvStatus;//show messages in this text view

    //declare variables for DatabaseReference ...............
    private DatabaseReference databaseReference;
    private DatabaseReference newCityReference;
    //private DatabaseReference newCityReference = null;

    //declare variables for FirebaseAuth ............ (need this for logout)
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_remove_corona_data);

        //initialize FirebaseApp....
        FirebaseApp.initializeApp(this);

        //initialize FirebaseAuth.....
        firebaseAuth = FirebaseAuth.getInstance();

        //initialize ****ALL**** the EditTexts ..........
        etCity = findViewById(R.id.etCity);
        etCases = findViewById(R.id.etCases);
        etRecoveries = findViewById(R.id.etRecoveries);

        //initialize TextView - tvStatus ..........
        tvStatus = findViewById(R.id.tvStatus);
    }

    //Add the code to add a new city and its related data ........
    public void doAddCityData(View view) {
        //write the code to add a new city and its related data ........
        //get all the data from the edit texts............
        //note the cases and recoveries are integers
        final String city = etCity.getText().toString();
        int numCase = Integer.parseInt(etCases.getText().toString());
        int recoveries = Integer.parseInt(etRecoveries.getText().toString());

        //make a object using the model class that you have written
        //Once a final variable has been assigned, it always contains the same value.
        final coronaCity ccData = new coronaCity(city, numCase, recoveries);

        //add the data under child node "cities" with key as the city.......
        //get a reference to the Firebase database
        //this refrence is refrencing the url for the realtime database and url is given inside googleService.json
        databaseReference = FirebaseDatabase.getInstance().getReference();

        if(databaseReference != null){
            Toast.makeText(this, databaseReference.toString(), Toast.LENGTH_LONG).show();
        }

        //create a new node under which you will add a new city data
        //create parient and child refrences with empty values
        Task task = databaseReference.child("cities").child(city).setValue(" ");

        task.addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    tvStatus.setText("City added!");
                }
                else{
                    //if sign in fails, display a message to the user
                    Log.w("doRegister", "createUserWithEmail:failure", task.getException());
                    tvStatus.setText("Add failed!" + task.getException());
                }
            }
        });
        //get the reference to the city under /cities node
        newCityReference = databaseReference.child("/cities").child(city);

        //Add the node with the city name
        //adds the data under city child node
        //then add the data under that new node.
        newCityReference.setValue(ccData).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                // Write was successful!
                Toast.makeText(AddRemoveCoronaDataActivity.this, city + " as added!!", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // Write failed
                Toast.makeText(AddRemoveCoronaDataActivity.this, city + " db error!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    //Delete a city by its name ..........
    public void doDeleteCityData(View view) {
        //write the code to delete a city by its name ..........
        final String city = etCity.getText().toString();

        //get a reference to the Firebase database
        databaseReference = FirebaseDatabase.getInstance().getReference();

        //get the refrence for the child
        //if we did not specify the child it will delete all childs
        DatabaseReference cityRef = databaseReference.child("/cities").child(city);

        if(cityRef != null){
            //a cities exists with this city name - delete
            Task removeTask = cityRef.removeValue();//remove all value of the child
            removeTask.addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        tvStatus.setText(city + "Removed");
                    }
                    else {
                        //if sign in fails, display a message to the user
                        tvStatus.setText("Remove Failed" + task.getException());
                    }
                }
            });
        }
        else {
            Toast.makeText(AddRemoveCoronaDataActivity.this, city + " not found!", Toast.LENGTH_LONG).show();
        }
    }

    //search/ read a cities by city
    public void doSearch(View view) {
        final String cityName = etCity.getText().toString();

        //get a reference to the Firebase database
        //STEP 1 - get the reference to your firebase database
        databaseReference = FirebaseDatabase.getInstance().getReference();

        //STEP 2 - get a reference to the child under your database ref
        DatabaseReference cityRef = databaseReference.child("/cities").child(cityName);

        //see https://firebase.google.com/docs/database/android/read-and-write?authuser=0

        //STEP 3 - create a ValueEventListener
        ValueEventListener carQueryListener = new ValueEventListener() {
            @Override
            //datasnapshot == data inside the database
            public void onDataChange(DataSnapshot dataSnapshot) { //data from firebase into DataSnapshot
                if (dataSnapshot.exists()) { //if snapshot exists it means a car exists at carRef
                    // Get the Car object and use the values to update the UI
                    //convert the dataSnapshot like json data format to java object
                    coronaCity ccData = dataSnapshot.getValue(coronaCity.class);
                    // ...
                    etCity.setText(ccData.city);
                    etCases.setText(ccData.numCase + " ");
                    etRecoveries.setText(ccData.recoveries + " ");
                    tvStatus.setText(cityName + " found!");
                }
                else {
                    Toast.makeText(AddRemoveCoronaDataActivity.this, cityName + " NOT found!", Toast.LENGTH_SHORT).show();
                    tvStatus.setText(cityName + " NOT found!");
                }
            }

            //handle network error and other errors
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("SEARCH", "loadPost:onCancelled", databaseError.toException());
                // ...
            }
        };

        //STEP 4 - add the value event lister to your car reference
        //this code will make the search | we need this to make the search working
        //this listener wait for data from the cloud to come to our application
        cityRef.addListenerForSingleValueEvent(carQueryListener);
    }

    //Update a cities by city
    public void doUpdateCity(View view) {
        final String cityName = etCity.getText().toString();

        //get a reference to the Firebase database
        databaseReference = FirebaseDatabase.getInstance().getReference();
        final DatabaseReference cityRef = databaseReference.child("/cities").child(cityName);

        //see https://firebase.google.com/docs/database/android/read-and-write?authuser=0

        ValueEventListener carQueryListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) { //if snapshot exists it means a car exists at carRef
                    // Get the Car object and get the posterEmail from it to check authorization
                    coronaCity ccData = dataSnapshot.getValue(coronaCity.class);

                    //get the new values from edit text and update them in the car object
                    ccData.city = etCity.getText().toString();
                    ccData.numCase = Integer.parseInt(etCases.getText().toString());
                    ccData.recoveries = Integer.parseInt(etRecoveries.getText().toString());

                    //update the cityRef with the new values from the editTexts
                    cityRef.setValue(ccData);
                    tvStatus.setText("City" + cityName + " updated!");
                }
                else {
                    Toast.makeText(AddRemoveCoronaDataActivity.this, cityName + " NOT found!", Toast.LENGTH_SHORT).show();
                    tvStatus.setText(cityName + " NOT found!");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("UPDATE", "loadPost:onCancelled", databaseError.toException());
                // ...
            }
        };

        cityRef.addListenerForSingleValueEvent(carQueryListener);
    }

    //write the code to move to the ViewAllCitiesDataActivity ..........
    public void doViewAllCitiesData(View view) {
        //write the code to move to the ViewAllCitiesDataActivity ..........
        Intent intent = new Intent(this, ViewAllCitiesDataActivity.class);
        startActivity(intent);

    }


    //Write the code to logout the current user and close the current activity
    public void doLogout(View view) {
        //Write the code to logout the current user and close the current activity
        firebaseAuth.signOut();
        finish();//close the current activity and go to the previews/ last activity that the user visted

    }

}
