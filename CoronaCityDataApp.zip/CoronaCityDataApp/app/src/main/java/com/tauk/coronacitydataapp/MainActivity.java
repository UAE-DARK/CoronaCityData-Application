package com.tauk.coronacitydataapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    //Add the required attributes for EditText ....
    private FirebaseAuth firebaseAuth;

    private EditText etEmail;
    private EditText etPassword;
    private TextView tvStatus;
    boolean loginWasSuccessfull;
    boolean registerWasSucessfull;

    //attribute for FirebaseAuth
    private String email123;
    private String password123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize FirebaseApp | connect your application to firebase
        FirebaseApp.initializeApp(this);

        //initialize FirebaseAuth | connect your application to firebase for authentication
        firebaseAuth = FirebaseAuth.getInstance();

        //initialize the EditTexts from which you have to read email and password
        //initialize edit text
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        tvStatus = findViewById(R.id.tvStatus);
    }


    public void doLogin(View view) {
        //read the email and password from EditTexts .......
        email123 = etEmail.getText().toString();
        password123 = etPassword.getText().toString();

        //verify the login using email/password FirebaseAuth ......
        firebaseAuth.signInWithEmailAndPassword(email123, password123).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    //get current user who is login
                    FirebaseUser userF = firebaseAuth.getCurrentUser();
                    tvStatus.setText(userF.toString());
                    loginWasSuccessfull = true;
                }
                //if login is invalid show error message in toast and in tvStatus textview
                else{
                    tvStatus.setText("Register Failed" + task.getException());
                }
            }
        });
        //if login credentials are OK start intent to go to AddRemoveCoronaDataActivity
        if(loginWasSuccessfull){
            Intent intent = new Intent(this, AddRemoveCoronaDataActivity.class);
            startActivity(intent);
        }
    }

    public void doRegister(View view) {
        //read the email and password from EditTexts .....
        email123 = etEmail.getText().toString();
        password123 = etPassword.getText().toString();

        //register the with email/password by using FirebaseAuth....
        //it will not register if password is less than 6 words
        //it will not register if email was existed
        firebaseAuth.createUserWithEmailAndPassword(email123, password123).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    FirebaseUser userF = firebaseAuth.getCurrentUser();
                    //tvStatus.setText(userF.toString());
                    registerWasSucessfull = true;
                }
                else{
                    //tvStatus.setText("Register Failed" + task.getException());
                    //if NOT successfull show Error message in Toast and in tvStatus textView
                    tvStatus.setText("Register Failed" + task.getException());
                }
            }
        });
        //if sucessfull show Success message in Toast and in tvStatus textview
        if(registerWasSucessfull){
            tvStatus.setText("Register OK. Login now!");
        }
    }
}
