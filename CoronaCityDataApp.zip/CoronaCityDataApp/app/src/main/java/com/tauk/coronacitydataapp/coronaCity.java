package com.tauk.coronacitydataapp;

public class coronaCity {
    //we dont want setter and getter so we put attributes as public
    public String city;
    public int numCase;
    public int recoveries;

    //defualt constructor
    public coronaCity(){}

    //constructor for display
    //paramiratrize constructor
    public coronaCity(String c, int n, int r){
        this.city = c;
        this.numCase = n;
        this.recoveries = r;
    }

    //setters and getters
    /*
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getNumCase() {
        return numCase;
    }

    public void setNumCase(int numCase) {
        this.numCase = numCase;
    }

    public int getRecoveries() {
        return recoveries;
    }

    public void setRecoveries(int recoveries) {
        this.recoveries = recoveries;
    }
    */

    //toString method
    @Override
    public String toString() {
        return "city= " + city + ", numCase=" + numCase + ", recoveries=" + recoveries + " \n";
    }
}
