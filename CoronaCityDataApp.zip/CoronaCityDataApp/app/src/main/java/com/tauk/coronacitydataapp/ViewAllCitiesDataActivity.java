package com.tauk.coronacitydataapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import android.os.Bundle;

public class ViewAllCitiesDataActivity extends AppCompatActivity {

    //declare variable for textview .........
    private TextView tvCitiesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_cities_data);

        //Initialize FirebaseApp.............
        FirebaseApp.initializeApp(this);

        //initialize the tvCitiesList ..........
        tvCitiesList = findViewById(R.id.tvCityDataList);

        //call the displayAllCities() method
        displayAllCities();
    }

    //Write the code to display all cities..........
    public void displayAllCities() {
        //get a reference to the database .....
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();

        //get a reference to the child node under which you have all data ......
        DatabaseReference cityRef = firebaseDatabase.getReference("/cities");

        //create a ChildEventListener and override all the methods in it .......
        StringBuilder sb = new StringBuilder();

        //the child city values will be used (cities --> city)
        ChildEventListener childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                //a new city has been added, add it to the displayed list
                coronaCity ccData = dataSnapshot.getValue(coronaCity.class);
                tvCitiesList.append(ccData.toString());
            }

            //when a child is changed/ removed then we are calling the method to check for changes and give the new updated data
            //data will become updated automatically
            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Toast.makeText(ViewAllCitiesDataActivity.this, dataSnapshot.getKey() + "changed!", Toast.LENGTH_SHORT).show();
                displayAllCities();
            }

            //data is removed from child relode and give new updated data to the application
            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                // A comment has changed, use the key to determine if we are displaying this
                // comment and if so remove it.
                String commentKey = dataSnapshot.getKey();
                Toast.makeText(ViewAllCitiesDataActivity.this, commentKey + " removed - RELOADING.........", Toast.LENGTH_SHORT).show();
                //reload and display again Toast.LENGTH_SHORT).show();
                displayAllCities();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // A comment has changed position, use the key to determine if we are
                // displaying this comment and if so move it.
                coronaCity ccData = dataSnapshot.getValue(coronaCity.class);
                String commentKey = dataSnapshot.getKey();
                Toast.makeText(ViewAllCitiesDataActivity.this, commentKey + " moved", Toast.LENGTH_SHORT).show();
                // ...
                displayAllCities();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ViewAllCitiesDataActivity.this, "Failed to load comments.", Toast.LENGTH_SHORT).show();
            }
        };
        //handle CRUD events on /cities
        //without this code the CRUD events will not work
        cityRef.addChildEventListener(childEventListener);
        tvCitiesList.setText(sb.toString());
    }

    public void backToAddRemove(View view){
        Intent intent = new Intent(this, AddRemoveCoronaDataActivity.class);
        startActivity(intent);
    }
}

